def add(a, b):
    """addition"""
    return a + b


def mult(a, b):
    """multiplication"""
    return a * b
