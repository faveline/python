# flake8: noqa

from .module1 import add
from .module1 import mult
from .module2 import count_in_list
