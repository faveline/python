cmd to do:
pip install . -vvv
python3 -m build
pip install ./dist/ft_package-0.0.1.tar.gz

cmd to check:
pip show -v ft_package
pip list | grep ft-package